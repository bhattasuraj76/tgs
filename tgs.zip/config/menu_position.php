<?php
return [
    'position' => [
        'navbar' => 'Navbar Menu',
        'footer' => 'Footer Menu',
    ],

];
