<?php
return [
    'site_owner' => 'Ananomynous',
    'site_name' => 'Token Generation System',
    'company_name' => 'TGS Pvt. Ltd.',
    'time_zone' => 'Asia/Katmandu',
    'primary_email' => 'surajvws@gmail.com',
    'secondary_email' => 'contact@tgs.com',
    'phone1' => '',
    'mobile1' => '',
    'address' => 'Kathmandu, Nepal',
    'postal_code' => '44600',
    'office_time' => '09 AM - 06 PM',
    'meta_title' => '',
    'meta_keywords' => '',
    'meta_description' => '',
    'facebook_link' => '',
    'twitter_link' => '',
    'instagram_link' => '',
    'youtube_link' => '',
    'linkedin_link'=>'',
    'pinterest_link' => '',
    'meta_title' => 'Token Generation System'
];
