<?php
return [
    'site_name' => 'Token Generation System',
    'company_name' => '',
    'time_zone' => 'Asia/Katmandu',
    'office_time' => '',
    'primary_email' => 'info@tgs.com',
    'phone1' => '+977-9860536208',
    'mobile1' => '+977-9860536208',
    'employee1' => '',
    'country' => '',
    'meta_title' => '',
    'office_start_time' => '10:00',
    'office_end_time' => '17:00',
    'break_start_time' => '14:00',
    'break_end_time' => '15:00',
    'max_quotas' => '50',
    'allocation_time' => '30'


];
