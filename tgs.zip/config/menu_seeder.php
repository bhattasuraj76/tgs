<?php
return [
    'navbar' => [
       
    ],

    'footer' => [
        
    ]

];
